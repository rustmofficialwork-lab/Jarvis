from __future__ import annotations

import asyncio
import base64
import binascii
import hashlib
import hmac
import json
import math
import os
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from typing import Any
from uuid import UUID, uuid4

import httpx
from .provider_router import (ProviderConfigurationError, ProviderUnavailable, request_with_failover, probe_providers)
from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response, status

UPSTREAM_URL = "https://openrouter.ai/api/v1/chat/completions"
DEFAULT_MODEL = os.getenv("OPENROUTER_MODEL", "openrouter/free")
def _bounded_int_env(name: str, default: int, minimum: int, maximum: int) -> int:
    """Read a bounded integer setting without making a bad deployment env crash startup."""
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(maximum, value))


MAX_REQUEST_BYTES = _bounded_int_env("MAX_REQUEST_BYTES", 12_582_912, 16_384, 25_165_824)
MAX_UPSTREAM_RESPONSE_BYTES = _bounded_int_env(
    "MAX_UPSTREAM_RESPONSE_BYTES", 2_000_000, 16_384, 8_388_608
)
UPSTREAM_TIMEOUT_SECONDS = _bounded_int_env("UPSTREAM_TIMEOUT_SECONDS", 45, 5, 90)


@asynccontextmanager
async def lifespan(_: FastAPI):
    yield


app = FastAPI(
    title="JARVIS Backend",
    description="Authenticated AI gateway for the JARVIS desktop assistant.",
    version="0.1.0",
    lifespan=lifespan,
    docs_url=None,
    redoc_url=None,
)


DEVICE_TOKEN_TTL_SECONDS = 30 * 24 * 60 * 60
REGISTRATION_WINDOW_SECONDS = 60 * 60
REGISTRATION_MAX_ATTEMPTS = 10
CHAT_WINDOW_SECONDS = 60
CHAT_MAX_REQUESTS_PER_WINDOW = 8
CHAT_DAY_SECONDS = 24 * 60 * 60
CHAT_MAX_REQUESTS_PER_DAY = 120
LEGACY_CHAT_MAX_REQUESTS_PER_WINDOW = 30
LEGACY_CHAT_MAX_REQUESTS_PER_DAY = 600
_rate_lock = asyncio.Lock()
_registration_attempts: dict[str, deque[float]] = defaultdict(deque)
_chat_attempts: dict[str, deque[float]] = defaultdict(deque)
_legacy_chat_attempts: dict[str, deque[float]] = defaultdict(deque)
_redis_client = None
_redis_client_url = ""

_REDIS_RATE_LIMIT_SCRIPT = """
local now = tonumber(ARGV[1])
local member = ARGV[2]
local retry_after = 0
for i, key in ipairs(KEYS) do
    local window = tonumber(ARGV[2 * i + 1])
    local maximum = tonumber(ARGV[2 * i + 2])
    redis.call("ZREMRANGEBYSCORE", key, "-inf", now - window)
    local count = redis.call("ZCARD", key)
    if count >= maximum then
        local oldest = redis.call("ZRANGE", key, 0, 0, "WITHSCORES")
        if oldest[2] then
            local wait = math.max(1, math.ceil(window - (now - tonumber(oldest[2]))))
            if wait > retry_after then retry_after = wait end
        end
    end
end
if retry_after > 0 then return {0, retry_after} end
for i, key in ipairs(KEYS) do
    local window = tonumber(ARGV[2 * i + 1])
    redis.call("ZADD", key, now, member)
    redis.call("PEXPIRE", key, (window + 5) * 1000)
end
return {1, 0}
"""


def _get_rate_limit_redis():
    """Return a shared Redis-compatible client when REDIS_URL is configured.

    If configured but unavailable, callers fail closed instead of silently
    reverting to per-process limits and weakening protection across instances.
    """
    global _redis_client, _redis_client_url
    url = os.getenv("REDIS_URL", "").strip()
    if not url:
        return None
    if not url.startswith(("redis://", "rediss://")):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Shared rate limiting is misconfigured.",
        )
    if _redis_client is None or _redis_client_url != url:
        try:
            from redis.asyncio import Redis
        except ImportError as exc:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Shared rate limiting dependency is unavailable.",
            ) from exc
        _redis_client = Redis.from_url(
            url, decode_responses=True, socket_connect_timeout=2,
            socket_timeout=2, health_check_interval=30,
        )
        _redis_client_url = url
    return _redis_client


async def _enforce_shared_rate_limits(
    namespace: str, rate_key: str, limits: list[tuple[int, int]], detail: str
) -> bool:
    """Atomically enforce multiple rolling windows across backend instances.

    Returns False only when REDIS_URL is unset, allowing the documented
    single-process in-memory development fallback.
    """
    client = _get_rate_limit_redis()
    if client is None:
        return False
    keys = [f"jarvis:rate:{namespace}:{rate_key}:{window}" for window, _ in limits]
    arguments: list[str] = [str(time.time()), uuid4().hex]
    for window, maximum in limits:
        arguments.extend((str(window), str(maximum)))
    try:
        result = await client.eval(
            _REDIS_RATE_LIMIT_SCRIPT, len(keys), *keys, *arguments
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Shared rate limiting is temporarily unavailable.",
        ) from exc
    allowed = int(result[0]) == 1
    if not allowed:
        retry_after = max(1, int(result[1]))
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=detail,
            headers={"Retry-After": str(retry_after)},
        )
    return True


def _device_token_secret() -> bytes:
    value = os.getenv("JARVIS_DEVICE_TOKEN_SECRET", "").strip()
    if len(value) < 32:
        return b""
    return value.encode("utf-8")


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _issue_device_token(device_id: str, now: int | None = None) -> tuple[str, int]:
    secret = _device_token_secret()
    if not secret:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Automatic device registration is not configured.",
        )
    issued_at = int(time.time()) if now is None else int(now)
    expires_at = issued_at + DEVICE_TOKEN_TTL_SECONDS
    payload = _b64url(json.dumps({
        "sub": device_id,
        "iat": issued_at,
        "exp": expires_at,
        "iss": "jarvis-backend",
        "aud": "jarvis-desktop",
    }, separators=(",", ":"), sort_keys=True).encode("utf-8"))
    signature = _b64url(hmac.new(secret, payload.encode("ascii"), hashlib.sha256).digest())
    return f"jdt1.{payload}.{signature}", expires_at


def _verify_device_token(token: str, now: int | None = None) -> str | None:
    secret = _device_token_secret()
    if not secret or not isinstance(token, str) or len(token) > 4096:
        return None
    try:
        parts = token.split(".")
        if len(parts) != 3 or parts[0] != "jdt1":
            return None
        _, payload_part, signature = parts
        expected = _b64url(hmac.new(
            secret, payload_part.encode("ascii"), hashlib.sha256
        ).digest())
        if not hmac.compare_digest(signature, expected):
            return None
        padded = payload_part + "=" * (-len(payload_part) % 4)
        payload_bytes = base64.b64decode(
            padded.encode("ascii"), altchars=b"-_", validate=True
        )
        payload = json.loads(payload_bytes)
        if not isinstance(payload, dict):
            return None
        current = int(time.time()) if now is None else int(now)
        subject = payload.get("sub")
        issued_at = payload.get("iat")
        expires_at = payload.get("exp")
        if (
            payload.get("iss") != "jarvis-backend"
            or payload.get("aud") != "jarvis-desktop"
            or not isinstance(subject, str)
            or not isinstance(issued_at, int)
            or isinstance(issued_at, bool)
            or not isinstance(expires_at, int)
            or isinstance(expires_at, bool)
            or expires_at <= current
            or expires_at <= issued_at
            or issued_at > current + 60
        ):
            return None
        # Tokens are issued only for canonical installation UUIDs.
        if str(UUID(subject)) != subject:
            return None
        return subject
    except (ValueError, TypeError, KeyError, json.JSONDecodeError, binascii.Error, UnicodeError, RecursionError):
        return None


async def _read_request_body_limited(
    request: Request, maximum: int, *, detail: str
) -> bytes:
    """Read a request incrementally and stop as soon as its body exceeds the limit.

    Do not use Request.body() here: it buffers the complete body before the
    caller can enforce a limit, which is unsafe for requests without a
    trustworthy Content-Length header (for example, chunked uploads).
    """
    chunks: list[bytes] = []
    total = 0
    async for chunk in request.stream():
        total += len(chunk)
        if total > maximum:
            raise HTTPException(status_code=413, detail=detail)
        chunks.append(chunk)
    return b"".join(chunks)


def _validate_json_nesting(raw: bytes, *, maximum_depth: int = 100) -> None:
    """Reject excessively nested JSON before the decoder builds deeply nested objects.

    Count only structural brackets outside strings, respecting JSON escapes. This
    provides a deterministic, low-cost bound across Python decoder versions.
    """
    depth = 0
    in_string = False
    escaped = False
    for byte in raw:
        if in_string:
            if escaped:
                escaped = False
            elif byte == 0x5C:  # backslash
                escaped = True
            elif byte == 0x22:  # quote
                in_string = False
            continue
        if byte == 0x22:
            in_string = True
        elif byte in (0x7B, 0x5B):  # { or [
            depth += 1
            if depth > maximum_depth:
                raise HTTPException(status_code=400, detail="Request JSON is nested too deeply.")
        elif byte in (0x7D, 0x5D):  # } or ]
            depth -= 1


def _prune_rate_buckets(
    buckets: dict[str, deque[float]], *, now: float, window: int, maximum_keys: int = 10_000
) -> None:
    for key in list(buckets):
        bucket = buckets[key]
        while bucket and bucket[0] <= now - window:
            bucket.popleft()
        if not bucket:
            buckets.pop(key, None)
    if len(buckets) > maximum_keys:
        excess = len(buckets) - maximum_keys
        for key in list(buckets)[:excess]:
            buckets.pop(key, None)


async def _enforce_window_limit(
    bucket: deque[float], *, now: float, window: int, maximum: int, detail: str
) -> None:
    while bucket and bucket[0] <= now - window:
        bucket.popleft()
    if len(bucket) >= maximum:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=detail,
            headers={"Retry-After": str(max(1, math.ceil(window - (now - bucket[0]))))},
        )
    bucket.append(now)


@app.post("/v1/devices/register")
async def register_device(request: Request) -> Response:
    length = request.headers.get("content-length")
    if length:
        try:
            if int(length) > 512:
                raise HTTPException(status_code=413, detail="Registration request is too large.")
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid Content-Length.")
    raw_body = await _read_request_body_limited(
        request, 512, detail="Registration request is too large."
    )
    _validate_json_nesting(raw_body)
    try:
        payload = json.loads(raw_body)
    except (ValueError, UnicodeDecodeError, RecursionError):
        raise HTTPException(status_code=400, detail="Request body must be valid JSON.")
    if not isinstance(payload, dict):
        raise HTTPException(status_code=422, detail="Request body must be a JSON object.")
    raw_device_id = payload.get("device_id")
    if not isinstance(raw_device_id, str) or len(raw_device_id) > 64:
        raise HTTPException(status_code=422, detail="A valid installation ID is required.")
    try:
        device_id = str(UUID(raw_device_id))
    except (ValueError, AttributeError):
        raise HTTPException(status_code=422, detail="A valid installation ID is required.")
    if device_id != raw_device_id.lower():
        raise HTTPException(status_code=422, detail="Installation ID must be a canonical UUID.")

    # Render appends the connecting client address to X-Forwarded-For.
    # Use the last entry (the proxy-appended address), not caller-supplied earlier entries.
    forwarded = request.headers.get("x-forwarded-for", "")
    forwarded_ip = forwarded.rsplit(",", 1)[-1].strip() if forwarded else ""
    client_ip = forwarded_ip or (request.client.host if request.client else "unknown")
    shared = await _enforce_shared_rate_limits(
        "registration", client_ip,
        [(REGISTRATION_WINDOW_SECONDS, REGISTRATION_MAX_ATTEMPTS)],
        "Too many device registrations from this network. Try again later.",
    )
    if not shared:
        now = time.monotonic()
        async with _rate_lock:
            _prune_rate_buckets(
                _registration_attempts, now=now, window=REGISTRATION_WINDOW_SECONDS
            )
            await _enforce_window_limit(
                _registration_attempts[client_ip],
                now=now,
                window=REGISTRATION_WINDOW_SECONDS,
                maximum=REGISTRATION_MAX_ATTEMPTS,
                detail="Too many device registrations from this network. Try again later.",
            )
    token, expires_at = _issue_device_token(device_id)
    return Response(
        content=json.dumps({"access_token": token, "token_type": "Bearer",
                            "expires_at": expires_at, "expires_in": DEVICE_TOKEN_TTL_SECONDS}),
        status_code=200,
        media_type="application/json",
        headers={"Cache-Control": "no-store", "Pragma": "no-cache"},
    )


def require_client_token(authorization: str | None = Header(default=None)) -> str | None:
    # HTTP authentication scheme names are case-insensitive (RFC 9110).
    parts = authorization.split(None, 1) if authorization else []
    supplied = (
        parts[1].strip()
        if len(parts) == 2 and parts[0].casefold() == "bearer"
        else ""
    )
    if not supplied:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials.")

    # Keep existing manually provisioned installations working during migration.
    legacy = os.getenv("JARVIS_CLIENT_TOKEN", "").strip()
    if len(legacy) >= 32 and hmac.compare_digest(supplied, legacy):
        return None

    device_id = _verify_device_token(supplied)
    if device_id is None:
        # Keep authentication failures indistinguishable to unauthenticated callers.
        # A missing signing secret also means the supplied device token cannot be trusted.
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired credentials.")
    return device_id


@app.get("/health")
async def health() -> dict[str, str]:
    # Do not expose secret/configuration status in a public health response.
    return {"status": "ok", "service": "jarvis-backend"}


@app.post("/v1/chat/completions")
async def chat_completions(
    request: Request, device_id: str | None = Depends(require_client_token)
) -> Response:
    # Device tokens are limited per installation. Legacy shared tokens remain
    # compatible, but are throttled per direct peer IP so they cannot bypass limits.
    # Do not trust X-Forwarded-For here: clients can supply that header themselves.
    now = time.monotonic()
    if device_id is not None:
        buckets = _chat_attempts
        rate_key = device_id
        minute_limit = CHAT_MAX_REQUESTS_PER_WINDOW
        day_limit = CHAT_MAX_REQUESTS_PER_DAY
    else:
        buckets = _legacy_chat_attempts
        rate_key = request.client.host if request.client else "unknown"
        minute_limit = LEGACY_CHAT_MAX_REQUESTS_PER_WINDOW
        day_limit = LEGACY_CHAT_MAX_REQUESTS_PER_DAY
    shared = await _enforce_shared_rate_limits(
        "chat-device" if device_id is not None else "chat-legacy",
        rate_key,
        [(CHAT_WINDOW_SECONDS, minute_limit), (CHAT_DAY_SECONDS, day_limit)],
        "JARVIS usage limit reached. Please try again later.",
    )
    if not shared:
        async with _rate_lock:
            _prune_rate_buckets(buckets, now=now, window=CHAT_DAY_SECONDS)
            bucket = buckets[rate_key]
            while bucket and bucket[0] <= now - CHAT_DAY_SECONDS:
                bucket.popleft()
            minute_count = sum(1 for stamp in bucket if stamp > now - CHAT_WINDOW_SECONDS)
            if minute_count >= minute_limit:
                oldest_minute_request = next(
                    stamp for stamp in bucket if stamp > now - CHAT_WINDOW_SECONDS
                )
                retry_after = max(
                    1, math.ceil(CHAT_WINDOW_SECONDS - (now - oldest_minute_request))
                )
            elif len(bucket) >= day_limit:
                retry_after = max(1, math.ceil(CHAT_DAY_SECONDS - (now - bucket[0])))
            else:
                retry_after = None
            if retry_after is not None:
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail="JARVIS usage limit reached. Please try again later.",
                    headers={"Retry-After": str(retry_after)},
                )
            bucket.append(now)

    length = request.headers.get("content-length")
    if length:
        try:
            if int(length) > MAX_REQUEST_BYTES:
                raise HTTPException(status_code=413, detail="Request is too large.")
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid Content-Length.")
    raw = await _read_request_body_limited(
        request, MAX_REQUEST_BYTES, detail="Request is too large."
    )
    _validate_json_nesting(raw)
    try:
        payload: dict[str, Any] = json.loads(raw)
    except (ValueError, UnicodeDecodeError, RecursionError):
        raise HTTPException(status_code=400, detail="Request body must be valid JSON.")
    if not isinstance(payload, dict):
        raise HTTPException(status_code=422, detail="Request body must be a JSON object.")
    messages = payload.get("messages")
    if not isinstance(messages, list) or not messages or len(messages) > 60:
        raise HTTPException(status_code=422, detail="Provide between 1 and 60 messages.")
    for item in messages:
        role = item.get("role") if isinstance(item, dict) else None
        if not isinstance(role, str) or role not in {"system", "user", "assistant", "tool"}:
            raise HTTPException(status_code=422, detail="Invalid chat message.")
    model = payload.get("model") or DEFAULT_MODEL
    if not isinstance(model, str) or not model.strip() or len(model) > 200:
        raise HTTPException(status_code=422, detail="Invalid model name.")
    # Provider endpoints are controlled only by backend environment configuration.
    # The desktop client cannot choose arbitrary upstream URLs or see provider secrets.
    try:
        response_body = await request_with_failover(
            payload,
            timeout=UPSTREAM_TIMEOUT_SECONDS,
            max_response_bytes=MAX_UPSTREAM_RESPONSE_BYTES,
        )
    except ProviderConfigurationError:
        raise HTTPException(status_code=503, detail="AI provider configuration is invalid.")
    except ProviderUnavailable as exc:
        message = str(exc)
        if message == "No AI provider is configured.":
            raise HTTPException(status_code=503, detail="AI provider is not configured.")
        raise HTTPException(status_code=exc.status_code, detail=message)
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="AI provider timed out. Please try again.")
    except httpx.RequestError:
        raise HTTPException(status_code=502, detail="AI provider is temporarily unreachable.")
    return Response(
        content=response_body,
        status_code=200,
        media_type="application/json",
        headers={"Cache-Control": "no-store"},
    )


@app.get("/v1/providers/health")
async def providers_health(_: str | None = Depends(require_client_token)) -> dict[str, Any]:
    """Run a tiny authenticated live request against each configured AI provider.

    Only provider name, model, and a coarse status are returned; credentials and
    upstream response bodies are never exposed.
    """
    try:
        results = await probe_providers(
            timeout=min(UPSTREAM_TIMEOUT_SECONDS, 15),
            max_response_bytes=256_000,
        )
    except ProviderConfigurationError:
        raise HTTPException(status_code=503, detail="AI provider configuration is invalid.")
    return {"providers": results}
