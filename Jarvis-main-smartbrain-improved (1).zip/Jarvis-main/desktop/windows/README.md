# JARVIS Desktop for Windows 11

This repository currently contains the native Windows laptop edition of JARVIS. The Android edition is maintained separately. It provides a blue JARVIS-themed command dashboard, separate conversation window, text input, spoken replies, persistent local chat history, offline-first private personal memory, a small allowlist of safe Windows app/website commands, and optional always-listening, local wake-word detection using openWakeWord and a single-word Jarvis ONNX model.

On first launch, JARVIS shows separate foreground consent prompts for microphone use and optional webcam use; upgrading to the current build re-asks once so older saved choices cannot silently suppress the prompts. If microphone access is accepted, JARVIS checks the default input device and releases it immediately; continuous voice listening still starts only when you activate it. If Windows blocks microphone access, JARVIS offers **Settings → Privacy & security → Microphone**. The camera consent only authorizes JARVIS to request webcam access later: the camera remains OFF at startup and is opened only after **ENABLE GESTURES** is clicked. Declining either permission leaves the rest of the HUD available. Windows controls the system-wide **Let desktop apps access your microphone/camera** privacy switches; Windows does not guarantee a separate per-app OS popup for traditional desktop apps. JARVIS never bypasses those Windows privacy controls. Windows sign-in startup is optional and uses the current user's settings; it does not require elevation.

## Requirements

- Windows 10/11, 64-bit
- Python 3.11 (recommended)
- Microphone and speakers/headphones (microphone access is optional until you enable voice setup; Windows controls the permission)
- Internet for online AI responses and the one-time download of offline speech models
- Offline AI: select **Install offline AI now** in the JARVIS installer (Ollama + `llama3.2:3b`, approximately 2 GB). This can also be run later with `setup_offline_ai.ps1` while online
- Either a custom-trained JARVIS ONNX wake-word model or the licensed community Jarvis fallback installed through the in-app **Set up wake word** flow ([details](JARVIS_WAKEWORD_SETUP.md)); custom-model training and import are documented in [WAKEWORD_FIRST_PARTY_MODEL.md](WAKEWORD_FIRST_PARTY_MODEL.md)
- Internet access for automatic JARVIS backend enrollment and online AI replies

Wake-word inference runs locally through openWakeWord after its ONNX model and shared feature files are installed; no Picovoice account, AccessKey, or cloud wake-word service is required. Voice activation also requires an enrolled local owner speaker profile ([setup](OWNER_VOICE_SETUP.md)); voice matching is not strong authentication. On first setup, JARVIS opens the model publisher's page and automatically detects, validates, and installs the completed download from the Windows Downloads folder; the user still needs to sign in on the publisher's page if requested and review the model license. Internet is required once for the model and shared feature files; subsequent wake-word detection runs locally. The custom model is not bundled because its publisher restricts redistribution. The detector requires two consecutive frames at the configured confidence threshold to reduce isolated false activations. Run `py wakeword_mic_test.py` from `desktop/windows` to perform a local quiet-room, spoken-wake-word, and background-noise microphone check; the test does not save or upload audio. Speech transcription tries Google's online recognizer first and automatically falls back to a local Vosk model when the network request fails. JARVIS automatically downloads the selected language model in the background on first launch (and after a language change) when internet is available; no Settings visit is required. After the one-time download, speech transcription and allowlisted Windows commands can work without internet. Online recognition requests have an eight-second network timeout. Offline models are stored under `%LOCALAPPDATA%\\JARVISDesktop\\models` and are not bundled into the installer. Model downloads are capped at 250 MB, and ZIP extraction rejects path traversal, symbolic links, unexpected top-level paths, archives with more than 20,000 entries, or expanded content larger than 500 MB. The desktop app does not hide or bypass Windows microphone privacy indicators.

## 3D hologram and optional hand gestures

The HUD includes an animated Three.js reactor overlay. The **ENABLE GESTURES** control is opt-in and requests webcam permission only after it is clicked. Hand landmarks are processed locally in the browser with MediaPipe; camera frames are not uploaded. Pinch clicks an enabled HUD control under the index fingertip, a fist toggles the reactor glow, and a deliberate horizontal swipe rotates the hologram. Gesture geometry, mirrored pointer mapping, and swipe timing have automated Node tests. The Windows build bundles pinned Three.js, MediaPipe runtime/WASM, and the Hand Landmarker task model, so gesture detection does not need a first-use model download. Disable gestures or close JARVIS to stop its camera stream. Camera support depends on the Windows WebView runtime and Windows camera privacy permissions. Face presence is a separate opt-in feature and still downloads its detector model on first activation.

### Face presence (not biometric identity unlock)

The **FACE PRESENCE** control is a separate opt-in camera feature. It runs MediaPipe face detection locally and changes the HUD reactor glow while a face is in view. It does not identify whose face is present, does not enroll or store biometric templates, and must not be used to unlock Windows or protect accounts. Stop Face Check to release the camera. The first activation downloads the detector runtime/model.

Voice examples include “Jarvis Chrome kholo”, “Google Chrome kholo”, “volume kam kar do”, and “awaaz badhao”. Local desktop actions remain restricted to the fixed allowlist.


## Safe agent actions and approval boundaries

The AI tool layer is deliberately allowlisted. It can open Notepad, Calculator, Paint, File Explorer, and Task Manager on Windows, and can open a public HTTP/HTTPS URL in the default browser when the user explicitly asks. Website navigation does not sign in, click controls, submit forms, upload files, or change website data. Local file tools are read-only and limited to small ordinary text files in Desktop, Documents, and Downloads.

Study/meeting/deep-work workflows show the exact apps and ask for confirmation before opening them. Creating or deleting recurring automations also asks for confirmation. Scheduled workflows run only after the user has separately approved the recurring schedule.

JARVIS does not currently provide general-purpose browser automation, email/message sending, purchases, account changes, arbitrary file deletion, or payment execution. These require dedicated provider integrations, account authorization, and a separate review/confirmation design; the AI model alone must never be treated as permission. JARVIS must report these limits instead of claiming an action succeeded. Never provide passwords, API keys, PINs, or one-time codes to JARVIS.

## Hybrid online and offline AI

JARVIS prefers its secured cloud AI gateway while internet and the configured providers are available. If the online command/provider request fails, it automatically tries the local Ollama runtime at `127.0.0.1:11434`. The offline model is `llama3.2:3b`; local requests use a 2,048-token context and a bounded reply length to reduce memory pressure on 8 GB laptops. Local prompts are sent only to the loopback Ollama service and are not routed through the JARVIS cloud backend. Offline AI does not provide live web search, weather, current news, or cloud-only tools.

**One-time setup (while connected to the internet):**

1. During the JARVIS Windows installer, leave **Install offline AI now** selected. The installer runs the setup script, installs Ollama with WinGet if needed, starts the local service, and downloads `llama3.2:3b` (approximately 2 GB).
2. If you skip it during installation, run `powershell -ExecutionPolicy Bypass -File .\\setup_offline_ai.ps1` from the installed JARVIS folder while online.
3. After the model is downloaded once, JARVIS checks cloud AI first on every request and automatically uses local Ollama when the cloud route is unavailable. If Windows restarted and Ollama is not running, JARVIS starts its local service automatically; when cloud access returns, the next request uses cloud AI again.

The local model is downloaded once per PC and is not embedded in the application binary. If the model has not been downloaded, JARVIS reports that offline setup is required rather than pretending offline AI is ready. The 3B model is a lightweight fallback; response quality and speed are lower than cloud AI and depend on available RAM/CPU. Close other memory-heavy apps if an 8 GB PC struggles.

## Offline reminders

JARVIS can create local reminders by typing or speaking commands such as:

- `remind me in 10 minutes to drink water`
- `remind me at 18:30 to call home`
- `mujhe 2 ghante baad meeting yaad dilana`
- `show reminders`
- `delete reminder 3`

Reminders are stored in `%LOCALAPPDATA%\\JARVISDesktop\\reminders.sqlite3` and work without internet. Due-time checks compare absolute timestamps, so reminders remain correctly ordered even when saved timestamps contain different UTC offsets or daylight-saving changes. On Windows, JARVIS registers a one-shot, current-user Task Scheduler task for each reminder. A small notification-only JARVIS process displays a native Windows reminder dialog even when the main app is closed. The user must still be signed in and the PC must be awake; reminders cannot wake a powered-off PC, and delivery after sleep depends on Windows Task Scheduler. If task registration fails, JARVIS reports the issue and its in-app reminder checker still works while the app remains running (including in the system tray). Uninstall removes JARVIS reminder tasks and its optional Windows sign-in startup entry; the local reminder database is preserved.

## Live web search, weather and news

When internet is available, JARVIS can answer these commands directly without an AI API key:

- `search web for Python tutorials` (also `search for ...` or `google ...`)
- `weather in Bhopal` (also `mausam Bhopal`; ask for a city if omitted)
- `latest news`, `news about technology`

Web search uses DuckDuckGo's HTML results, headlines use Google News RSS with India editions, and current conditions use Open-Meteo geocoding and forecast APIs. These public services do not require a separate key or paid package. Online requests use HTTPS, a 12-second timeout, and a response-size limit. Search/news results include source links; JARVIS does not execute page content or arbitrary commands. Live services require internet and do not work offline. Weather lookup needs a city name rather than assuming the Windows PC's location.

## Offline PC health status

Ask or type `system status`, `PC status`, `system health`, or `system status batao` to get a read-only snapshot of CPU, memory, system-drive usage, battery/charging state, network-interface status, and uptime. This uses the locally installed psutil package and works without internet. Hardware sensors that Windows does not expose are reported as unavailable; this command does not change system settings or run shell commands.

## Focus Mode, workflows and recurring automations

These features run locally and use a small SQLite database in the JARVIS app-data folder.

- **Focus Mode / Pomodoro:** say `start pomodoro`, `start focus for 45 minutes`, `focus status`, or `stop focus`. Sessions persist across app restarts.
- **Smart workflows:** `run study workflow`, `run meeting workflow`, or `run deep work workflow`. Workflows only launch fixed, allowlisted apps (Notepad, Calculator, browser, Task Manager); no shell commands or arbitrary scripts.
- **Recurring automation:** `repeat study workflow every 60 minutes`, `list automations`, or `delete automation 1`. Intervals are limited to 5 minutes–7 days. If a workflow launch fails, JARVIS schedules a retry in five minutes instead of silently losing that run. Automations run while JARVIS is running (including its tray mode); they are not guaranteed while Windows/JARVIS is shut down.

## Live process and app resource usage

Ask JARVIS `top processes`, `show top processes`, or `which apps use most RAM` to see a read-only snapshot of the processes using the most memory, including each process's PID and current CPU/RAM percentages. JARVIS skips processes Windows does not allow it to inspect and limits the report to five entries. This feature never terminates, changes, or launches a process and works locally without an AI API key.

## Search for and open local files

Type or say `find file budget`, `look for file budget`, `file dhundo notes`, `file dhoondho notes`, or `फाइल ढूँढो report`. Choose a folder when prompted; JARVIS searches filenames only (not file contents), skips hidden files and symlinks, and caps work at 50 results / 5,000 directories. After a search, say or type `open file 2` (also `open the second file`, `second result kholo`, `file khol do 2`, or `दूसरी फाइल खोलो`) to select a numbered result from the latest search. JARVIS asks for confirmation before opening it with the Windows default application. For safety, only supported document and media formats are eligible; executables, scripts, shortcuts, and web shortcut files are not opened through search results. If a result was moved or deleted, JARVIS refuses to open it.

## Read local documents offline

Type `read file` (or `document kholo`) in the JARVIS command bar and choose a file. JARVIS extracts text locally from PDF, Word DOCX, TXT, Markdown, CSV, JSON, common code and other text files. The selected document is not uploaded. For AI help, type `summarize document` or `ask document what is the invoice date` (also `document se pucho invoice date kya hai`) and select the file. JARVIS explains the destination and asks permission before sending extracted text to your configured online AI service. If you decline, the file stays local. Document text and AI answers are not persisted in chat history. PDF extraction supports selectable text, not scanned-image OCR. Reads are limited to 15 MB, 100 PDF pages, and 40,000 extracted characters; the chat preview is capped at 12,000 characters.

## Updates

JARVIS checks the official rolling Windows release once at startup. You can also use **SETTINGS → Check for updates** to check manually. Main-branch Windows builds publish to the `jarvis-latest` prerelease with a unique build version, installer, `JARVIS-Portable-x64.zip` (the complete onedir app), and SHA-256 checksums. JARVIS downloads the installer only after confirmation, verifies its SHA-256 against the published checksum file, and asks before launching the installer. Version-tagged releases (`v1.1.0`, etc.) remain available as separate manual releases.

## Run from source

Open PowerShell in this folder:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python jarvis_desktop.py
```

On first launch, JARVIS quietly registers this installation with the official backend and stores its unique, short-lived credential in Windows Credential Manager. If the first launch is offline, registration retries automatically until the backend becomes reachable. If a saved credential expires, JARVIS renews it automatically when the next online request is made. No account, manual backend token, or OpenRouter key is required. The OpenRouter secret stays on the server. If Windows Credential Manager is unavailable, the credential remains in memory for that run and JARVIS can register again next time.

For optional wake-word listening, install the single-word Jarvis ONNX model by following [JARVIS_WAKEWORD_SETUP.md](JARVIS_WAKEWORD_SETUP.md). The wake-word detector then runs locally; there is no wake-word API key to configure. The default AI endpoint and model are already configured. A legacy backend token field remains optional for existing installations; leave it blank for automatic enrollment.

To test without a wake-word model installed, type a message and press **Send**; voice listening requires the Jarvis ONNX model described in [JARVIS_WAKEWORD_SETUP.md](JARVIS_WAKEWORD_SETUP.md). The main window shows the blue holographic command dashboard with an animated reactor, resource panel, quick-access folders, and voice/chat controls. Use CHAT LOG to open the conversation transcript and SETTINGS to configure the backend and optional Windows sign-in startup. Closing the main window moves JARVIS to the Windows system tray; use the tray menu to reopen it, activate/stop voice listening, or fully exit. The startup option adds/removes a per-user Windows Run registry entry and does not require administrator access. Conversations are saved in `%APPDATA%\\JARVISDesktop\\chat_history.json`; personal memories are stored separately in `%LOCALAPPDATA%\\JARVISDesktop\\memory.sqlite3` and remain available offline. Say `remember that I prefer Hinglish`, `what do you remember`, or open CHAT LOG → Manage memory to add, edit, and delete saved memories. Memory capture is explicit; JARVIS does not silently save arbitrary chat content. Passwords, API keys, tokens, OTPs, and secrets are blocked. Sharing saved memories with online AI chats is off by default and can be enabled in Settings. Clear conversation does not delete personal memories. Voice and typed Windows commands ignore polite prefixes such as `please`, `hey Jarvis`, `can you`, and `zara`, plus courtesy endings such as `please` or `now`; the final action must still exactly match the safe command allowlist. Exact commands currently supported include `open notepad`, `open calculator`, `open downloads`, `open downloads folder`, `open file explorer`, `open task manager`, `open browser`, `open google`, `open youtube`, `volume up`, `volume down`, `mute`, `play pause`, `next track`, and `previous track`, `brightness up`, and `brightness down`. Media/volume actions use fixed Windows multimedia key events; brightness changes use 10-point steps on the primary supported display; arbitrary shell commands are not executed. The dashboard POWER control opens a confirmation dialog for shutdown/restart; both are scheduled 60 seconds ahead and can be cancelled from the same dialog. These actions are never triggered by an unconfirmed chat phrase. Say “Jarvis”, wait for the listening status, then speak a command. After wake detection, the microphone checks for a command in cancellable one-second start-of-phrase intervals; stopping during an already-started phrase may still wait until the current phrase capture ends (up to the configured 12-second phrase limit). You can also send a typed message without enabling the microphone.

Keys are stored using the Windows Credential Manager through Python's `keyring` package. The endpoint and model are stored in the current user's AppData folder. Do not put keys in source files, screenshots, or Git commits.

## Build a Windows executable

From the same folder, after installing requirements:

```powershell
pyinstaller --noconfirm --clean --onedir --windowed --add-data "jarvis_hud.html;." --collect-all webview --collect-all bottle --collect-all proxy_tools --collect-all pystray --collect-all PIL --collect-all vosk --name JARVIS jarvis_desktop.py
```

The application is written to `dist\\JARVIS\\` (run `dist\\JARVIS\\JARVIS.exe`). Keep the complete folder together; the HUD and collected WebView/runtime dependencies are required. This matches the automated Windows build and installer. Some endpoint, microphone, or ONNX model configurations can require troubleshooting on the target PC.

## Current scope and limitations

- This Windows edition has its own UI, settings, voice loop, and local chat history. It does not sync its history or settings with the separate Android edition.
- Speech recognition supports online Google transcription with local Vosk fallback. JARVIS automatically prepares the selected small model in the background while online; Hindi (India), English (India), and English (US) have separate offline models. Hindi/Hinglish recognition quality depends on the selected model and accent; mixed-language accuracy is not guaranteed. Cloud AI replies and live web/AI features require internet; after the one-time Ollama model download, general AI chat can fall back to the local model without internet. AI API responses are capped at 2 MB to prevent unexpectedly large payloads from exhausting desktop memory. Use STOP SPEECH on the dashboard or Stop speaking in the tray menu to interrupt spoken replies.
- Test the microphone and wake word on the actual Windows laptop before relying on continuous listening.


## Automated installer artifact

The Windows CI builds a portable `JARVIS\\` application folder (containing `JARVIS.exe` and its runtime files) and an Inno Setup installer named `JARVIS-Setup-x64.exe`. After a successful `JARVIS Project Checks and Windows Build` workflow, download the `JARVIS-Windows-Installer-x64` artifact from the run's Artifacts section. The portable artifact is named `JARVIS-Windows-Portable-x64` and must be extracted as a complete folder. The installer creates a Start Menu shortcut and offers an optional Desktop shortcut. It installs per-user without administrator privileges; automatic startup is opt-in from SETTINGS and can be disabled there.
